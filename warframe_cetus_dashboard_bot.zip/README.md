
# Warframe Cetus Bot + Dashboard

Includes:
✓ Cetus bounties only  
✓ Web dashboard on port 8080  
✓ Slash command: /cetus  

Upload to HostMyBot and set:
DISCORD_TOKEN = your bot token
